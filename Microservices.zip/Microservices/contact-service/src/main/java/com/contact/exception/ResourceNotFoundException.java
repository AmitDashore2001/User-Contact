package com.contact.exception;

public class ResourceNotFoundException {
	
	

}
